## 0.2.5 (unreleased)


## 0.2.4 (July 11, 2012)

### Improvements

* Update PPA to guilhem-fr (supports up to ubuntu/precise). ([@fnichol][])


## 0.2.2 (July 10, 2012)

### Improvements

* Pull request [#1](https://github.com/fnichol/chef-swftools/pull/1): Use
  apt\_repository resource. ([@phlipper][])
* Add TravisCI to run Foodcritic linter. ([@fnichol][])
* Reorganize README with section links. ([@fnichol][])


## 0.2.0 (October 19, 2011)

The initial release.

[@fnichol]: https://github.com/fnichol
[@phlipper]: https://github.com/phlipper
