#
# Cookbook Name:: line
# Recipe:: default
#
# Copyright (C) 2013 YOUR_COPYRIGHT
#
# All rights reserved - Do Not Redistribute
#
