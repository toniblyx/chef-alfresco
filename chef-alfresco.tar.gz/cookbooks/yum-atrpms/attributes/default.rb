default['yum-atrpms']['repositories'] = %w(
  atrpms atrpms-debuginfo atrpms-source
  atrpms-testing atrpms-testing-debuginfo atrpms-testing-source
  atrpms-bleeding atrpms-bleeding-debuginfo atrpms-bleeding-source
)
