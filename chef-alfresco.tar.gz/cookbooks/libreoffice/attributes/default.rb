default['libreoffice']['version']        = "4.0"
default['libreoffice']['repo']           = false
default['libreoffice']['install_method'] = "package"
default['libreoffice']['upgrade']        = false
